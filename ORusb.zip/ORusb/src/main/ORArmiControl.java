package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.RemoteException;

import ora.rmi.ORArmiMenu;

public class ORArmiControl {

    private static ORArmiMenu menu;

    public ORArmiControl() {
        // default
    }

    public void connectToMenu(String ip) {
        try {
            menu = (ORArmiMenu) Naming.lookup("//" + ip + "/RemoteMenu");
            System.out.println("Connected to " + ip);
        } catch ( Exception e ) {
            System.out.println("Exception connecting to " + ip);
        }
    }

    public void disconnectFromMenu() {
        menu = null;
    }

    public void uploadFile(String programName) {
        if ( menu == null ) {
            return;
        }
        try {
            File file = new File(programName);
            FileInputStream in = new FileInputStream(file);
            byte[] data = new byte[(int) file.length()];
            in.read(data);
            System.out.println("Uploading " + file.getName());
            menu.uploadFile("/home/lejos/programs/" + file.getName(), data);
            in.close();
        } catch ( IOException ioe ) {
            System.out.println("IOException uploading program");
        }
    }

    public void runProgram(String programName) {
        System.out.println("Running " + programName);
        try {
            menu.runProgram(programName.replaceFirst(".jar", ""));
        } catch ( RemoteException e ) {
            System.out.println("RemoteException running program");
        }
    }

    public String getlejosVersion() {
        try {
            return menu.getVersion();
        } catch ( RemoteException e ) {
            System.out.println("error @ lejosversion");
        }
        return null;
    }

    public String getORAversion() {
        try {
            return menu.getORAversion();
        } catch ( RemoteException e ) {
            System.out.println("error @ oraversion");
        }
        return null;
    }

    public String getBrickname() {
        try {
            return menu.getName();
        } catch ( RemoteException e ) {
            System.out.println("error @ name");
        }
        return null;
    }

    public String getBatteryVoltage() {
        try {
            return menu.getORAbattery();
        } catch ( RemoteException e ) {
            System.out.println("error @ battery");
        }
        return null;
    }

    public void setORAregistration(boolean status) {
        try {
            menu.setORAregistration(status);
        } catch ( RemoteException e ) {
            System.out.println("error @ setorareg");
        }
    }

    public void runORAprogram(String programName) {
        try {
            menu.runORAprogram(programName);
        } catch ( RemoteException e ) {
            System.out.println("error @ runoraprogram");
        }
    }
}
