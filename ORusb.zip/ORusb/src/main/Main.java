package main;

import java.io.IOException;
import java.net.InetAddress;

import brick.ORApushCmdUSB;

public class Main {

    public static final boolean TRUE = true;

    public static String ip = "10.0.1.1";
    public static boolean detected = false;

    public static final String TEMPDIRECTORY = System.getenv("USERPROFILE");

    public static void main(String[] args) throws IOException, InterruptedException {

        while ( !InetAddress.getByName("10.0.1.1").isReachable(3000) ) {
            Thread.sleep(1000);
        }
        ORApushCmdUSB orlabUSB = new ORApushCmdUSB("10.0.1.10:1999");
        orlabUSB.mainloop(ip);

    }

}
