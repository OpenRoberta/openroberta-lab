package brick;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;

import main.Main;

import org.json.JSONObject;

public class ORApushCmdUSB {

    private URL pushServiceURL;
    private URL brickData;
    private URL brickProgram;
    private HttpURLConnection serverHttpURLConnection;
    private HttpURLConnection brickHttpURLConnection;

    private final ORAdownloader oraDownloader;

    //private final ORAupdater oraUpdater;

    //brick data keywords
    public static final String KEY_TOKEN = "token";
    public static final String KEY_CMD = "cmd";

    //brickdata + cmds send to server
    private static final String CMD_REGISTER = "register";
    private static final String CMD_PUSH = "push";

    // cmds receive from server
    private static final String CMD_REPEAT = "repeat";
    private static final String CMD_ABORT = "abort";
    private static final String CMD_UPDATE = "update";
    private static final String CMD_DOWNLOAD = "download";
    private static final String CMD_CONFIGURATION = "configuration";

    public ORApushCmdUSB(String serverBaseIP) {
        // - {"macaddr":"20-E5-2A-2E-79-E8","cmd":"register","token":"VUUY1O7I","brickname":"Roberta01","lejosversion":"0.9.0-beta","battery":"8.3","menuversion":"1.0.1"}

        try {
            this.pushServiceURL = new URL("http://" + serverBaseIP + "/pushcmd");
            this.brickData = new URL("http://10.0.1.1:80/openroberta");
            this.brickProgram = new URL("http://10.0.1.1:80/program");
        } catch ( MalformedURLException e ) {
            // ok
        }
        this.oraDownloader = new ORAdownloader(serverBaseIP);
        //        this.oraUpdater = new ORAupdater(serverBaseIP);
    }

    private JSONObject requestBrickData() {
        OutputStream os = null;
        BufferedReader br = null;
        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("cmd", "getdata");

            this.brickHttpURLConnection = openBrickConnection();

            os = this.serverHttpURLConnection.getOutputStream();
            os.write(this.brickData.toString().getBytes("UTF-8"));

            br = new BufferedReader(new InputStreamReader(this.serverHttpURLConnection.getInputStream()));
            StringBuilder responseStrBuilder = new StringBuilder();
            String responseString;
            while ( (responseString = br.readLine()) != null ) {
                responseStrBuilder.append(responseString);
            }
            return new JSONObject(responseStrBuilder.toString());

        } catch ( SocketTimeoutException ste ) {
            System.out.println("Timeout!");
            return null;
        } catch ( IOException ioe ) {
            ioe.printStackTrace();
            return null;
        } finally {
            try {
                if ( os != null ) {
                    os.close();
                }
                if ( br != null ) {
                    br.close();
                }
            } catch ( IOException e ) {
                // ok
            }
        }
    }

    public void mainloop(String ip) {
        OutputStream os = null;
        BufferedReader br = null;
        boolean registered = false;

        while ( Main.TRUE ) {
            try {
                JSONObject brickData = requestBrickData();
                if ( registered ) {
                    brickData.put(KEY_CMD, CMD_PUSH);
                } else {

                    String token = new ORAtokenGenerator().generateToken();
                    brickData.put(KEY_TOKEN, token);
                    brickData.put(KEY_CMD, CMD_REGISTER);
                    System.out.println("ORA register: " + this.brickData);
                }
                this.serverHttpURLConnection = openServerConnection();

                os = this.serverHttpURLConnection.getOutputStream();
                os.write(this.brickData.toString().getBytes("UTF-8"));

                br = new BufferedReader(new InputStreamReader(this.serverHttpURLConnection.getInputStream()));
                StringBuilder responseStrBuilder = new StringBuilder();
                String responseString;
                while ( (responseString = br.readLine()) != null ) {
                    responseStrBuilder.append(responseString);
                }
                JSONObject responseEntity = new JSONObject(responseStrBuilder.toString());

                String command = responseEntity.getString("cmd");
                System.out.println("ORA cmd from server: " + command);
                switch ( command ) {
                    case CMD_REPEAT:
                        if ( registered == false ) {
                            registered = true;
                            //this.remotecontrol.setORAregistration(true);
                        }
                        break;
                    case CMD_ABORT:
                        return;
                    case CMD_UPDATE:
                        //this.oraUpdater.update();
                        break;
                    case CMD_DOWNLOAD:
                        String programName = this.oraDownloader.downloadProgram(brickData);
                        System.out.println("Downloaded: " + programName);
                        //this.remotecontrol.uploadFile(Main.TEMPDIRECTORY + "\\" + programName);
                        //this.remotecontrol.runORAprogram(programName);
                        break;
                    case CMD_CONFIGURATION:
                        break;
                    default:
                        System.out.println("ORA unknown command from server, do nothing!");
                        break;
                }
            } catch ( SocketTimeoutException ste ) {
                System.out.println("Timeout!");
                return;
            } catch ( IOException ioe ) {
                ioe.printStackTrace();
                return;
            } finally {
                try {
                    if ( os != null ) {
                        os.close();
                    }
                    if ( br != null ) {
                        br.close();
                    }
                } catch ( IOException e ) {
                    // ok
                }
            }
        }

    }

    private HttpURLConnection openBrickConnection() throws SocketTimeoutException, IOException {
        HttpURLConnection httpURLConnection = (HttpURLConnection) this.brickData.openConnection();
        httpURLConnection.setDoInput(true);
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setReadTimeout(30000);
        httpURLConnection.setRequestProperty("Content-Type", "application/json; charset=utf8");
        return httpURLConnection;
    }

    private HttpURLConnection openServerConnection() throws SocketTimeoutException, IOException {
        HttpURLConnection httpURLConnection = (HttpURLConnection) this.pushServiceURL.openConnection();
        httpURLConnection.setDoInput(true);
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setReadTimeout(330000);
        httpURLConnection.setRequestProperty("Content-Type", "application/json; charset=utf8");
        return httpURLConnection;
    }

}
